export default function Dashboard() {
  return (
    <div className="rounded-lg p-6 bg-[#1a1224] shadow-md">
      <h2 className="text-2xl font-bold mb-2">Dashboard</h2>
      <p className="opacity-80">Hier kommt dein Dashboard-Content rein.</p>
    </div>
  );
}