import React, { useEffect, useState, type JSX } from "react";
import { motion, AnimatePresence, useMotionValue, useSpring } from "framer-motion";
import { Play, Pause, RefreshCw, Trash2 } from "lucide-react";

/* ---------------------- Types ---------------------- */
type Instance = {
  name: string;
  players: string[];
  tps: number;
};

type InstanceManager = {
  state: string;
  domain: string;
  name: string;
  cpu_percent: number;
  ram_used_mb: number;
  ram_total_mb: number;
  instances: Instance[];
};

/* ---------------------- small animated number hook ---------------------- */
function useAnimatedNumber(value: number, precision = 0) {
  const mv = useMotionValue(value);
  const spring = useSpring(mv, { stiffness: 140, damping: 20 });
  const [display, setDisplay] = useState<number>(value);

  useEffect(() => void mv.set(value), [value, mv]);

  useEffect(() => {
    const unsub = spring.on("change", (v) => setDisplay(Number(v.toFixed(precision))));
    return () => unsub();
  }, [spring, precision]);

  return display;
}

/* ---------------------- UI helpers (header / bg) ---------------------- */
const NeonBackground: React.FC = () => (
  <>
    <div className="fixed inset-0 -z-10">
      <div className="absolute inset-0 bg-gradient-to-b from-black via-[#07030a] to-[#0b0410]" />
      <div className="absolute -top-48 -left-48 w-[640px] h-[640px] rounded-full bg-gradient-to-br from-purple-700/18 to-purple-900/6 blur-3xl pointer-events-none" />
      {/* subtle tile grid */}
      <div className="absolute inset-0 grid grid-cols-12 gap-[1px] opacity-5 pointer-events-none">
        {Array.from({ length: 12 * 12 }).map((_, i) => <div key={i} className="bg-purple-600/8" />)}
      </div>
    </div>
  </>
);

const HeaderBar: React.FC = () => (
  <header className="w-full fixed top-0 left-0 z-30 backdrop-blur-md bg-black/30 border-b border-white/6">
    <div className="max-w-6xl mx-auto px-6 py-3 flex items-center justify-between gap-4">
      <div className="flex items-center gap-4">
        <div className="w-12 h-10 rounded-lg bg-gradient-to-br from-purple-700 to-purple-500 flex items-center justify-center shadow-xl">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2L3 7v6c0 5 3.58 9.74 9 11 5.42-1.26 9-6 9-11V7l-9-5z" />
          </svg>
        </div>
        <div>
          <div className="text-white font-semibold">Instance Manager</div>
          <div className="text-xs text-purple-200/60">Manage your Minecraft instance managers</div>
        </div>
      </div>

      <nav className="flex items-center gap-3">
        <button className="px-3 py-1.5 rounded-lg text-sm bg-white/5 border border-white/6 hover:bg-white/6">Overview</button>
        <button className="px-3 py-1.5 rounded-lg text-sm bg-white/5 border border-white/6 hover:bg-white/6">Logs</button>
        <button className="px-3 py-1.5 rounded-lg text-sm bg-white/5 border border-white/6 hover:bg-white/6">Settings</button>
      </nav>
    </div>
  </header>
);

/* ---------------------- Main Component ---------------------- */
export default function InstancesPage(): JSX.Element {
  const [instanceManagers, setInstanceManagers] = useState<InstanceManager[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const [showModal, setShowModal] = useState(false);
  const [newDomain, setNewDomain] = useState("");
  const [newName, setNewName] = useState("");
  const [formError, setFormError] = useState<string | null>(null);

  // toast
  const [toast, setToast] = useState<{ type: "ok" | "error"; text: string } | null>(null);
  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(null), 3500);
    return () => clearTimeout(id);
  }, [toast]);

  // initial fetch + polling
  const fetchInstanceManagers = async () => {
    setError(null);
    try {
      const res = await fetch("/api/instance_summary");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data: InstanceManager[] = await res.json();
      setInstanceManagers(data || []);
    } catch (err: any) {
      setError(err.message || "Failed to fetch");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setLoading(true);
    fetchInstanceManagers();
    const id = setInterval(fetchInstanceManagers, 60_000);
    return () => clearInterval(id);
  }, []);

  // add IM
  const handleAddInstanceManager = async () => {
    setFormError(null);
    if (!newDomain.trim() || !newName.trim()) {
      setFormError("Domain + Name required");
      return;
    }

    try {
      const res = await fetch("/api/create_im", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain: newDomain.trim(), name: newName.trim() }),
      });
      if (!res.ok) throw new Error(`Server ${res.status}`);
      setToast({ type: "ok", text: "Instance Manager created" });
      setShowModal(false);
      setNewDomain("");
      setNewName("");
      fetchInstanceManagers();
    } catch (err: any) {
      setFormError(err.message || "Create failed");
    }
  };

  // delete IM
  const handleDeleteInstanceManager = async (im: InstanceManager) => {
    const confirmed = confirm(`Delete Instance Manager "${im.name}" (${im.domain})?`);
    if (!confirmed) return;

    const prev = instanceManagers;
    setInstanceManagers((s) => s.filter((x) => !(x.domain === im.domain && x.name === im.name)));

    try {
      const res = await fetch("/api/delete_im", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain: im.domain, name: im.name }),
      });
      if (!res.ok) throw new Error(`Delete failed ${res.status}`);
      setToast({ type: "ok", text: "Deleted" });
    } catch (err: any) {
      setInstanceManagers(prev);
      setToast({ type: "error", text: `Delete failed: ${err.message || err}` });
    }
  };

  // generic action (start/stop/restart) at manager-level
  const handleManagerAction = async (im: InstanceManager, action: "start" | "stop" | "restart") => {
    try {
      // optimistic UI could be added; here we call API and show toast
      const res = await fetch("/api/im_action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain: im.domain, name: im.name, action }),
      });
      if (!res.ok) throw new Error(`Action failed ${res.status}`);
      setToast({ type: "ok", text: `${action} requested` });
      // optional refresh
      fetchInstanceManagers();
    } catch (err: any) {
      setToast({ type: "error", text: `Action error: ${err.message || err}` });
    }
  };

  return (
    <div className="min-h-screen">
      <NeonBackground />
      <HeaderBar />
      <main className="pt-24 px-6 pb-16 max-w-6xl mx-auto">
        <div className="mb-6 flex items-center justify-between gap-4">
          <div>
            <h2 className="text-3xl font-bold text-white">Instance Managers</h2>
            <p className="text-sm text-purple-200/70">Overview · Manage, start & monitor your IMs</p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setFormError(null);
                setNewDomain("");
                setNewName("");
                setShowModal(true);
              }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-br from-green-600 to-green-500 text-white shadow-lg hover:scale-99 active:scale-95 transition"
            >
              <Play size={16} /> Add IM
            </button>

            <button
              onClick={() => fetchInstanceManagers()}
              className="px-3 py-2 rounded-lg bg-white/5 border border-white/6 text-sm hover:bg-white/6 transition"
            >
              Refresh
            </button>
          </div>
        </div>

        {/* list */}
        {loading && <div className="animate-pulse text-purple-200/60">Loading…</div>}
        {error && <div className="text-red-400">{error}</div>}

        {!loading && !error && (
          <div className="flex flex-col gap-4">
            {instanceManagers.length === 0 ? (
              <div className="text-center text-purple-200/40 italic py-8 rounded-xl bg-black/30 border border-purple-800/20">
                No Instance Managers yet — add one with the button above
              </div>
            ) : (
              instanceManagers.map((im, i) => (
                <ManagerCard
                  key={im.domain + "::" + im.name}
                  im={im}
                  index={i}
                  onDelete={() => handleDeleteInstanceManager(im)}
                  onAction={(a) => handleManagerAction(im, a)}
                />
              ))
            )}
          </div>
        )}

        {/* modal */}
        <AnimatePresence>
          {showModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-start justify-center pt-24"
            >
              <div className="absolute inset-0 bg-black/60" onClick={() => setShowModal(false)} />

              <motion.div
                initial={{ y: -8, scale: 0.98 }}
                animate={{ y: 0, scale: 1 }}
                exit={{ y: -8, scale: 0.98, opacity: 0 }}
                transition={{ duration: 0.18 }}
                className="relative z-10 w-full max-w-md p-6 bg-gradient-to-br from-black/75 to-purple-950/70 rounded-2xl shadow-2xl border border-purple-800/40"
                onKeyDown={(e) => e.key === "Escape" && setShowModal(false)}
              >
                <h3 className="text-lg font-semibold text-white mb-3">Add Instance Manager</h3>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleAddInstanceManager();
                  }}
                  className="flex flex-col gap-3"
                >
                  <input
                    placeholder="Domain (example.local:25566)"
                    value={newDomain}
                    onChange={(e) => setNewDomain(e.target.value)}
                    className="p-2 rounded bg-[#120b1a] text-white placeholder-purple-300"
                    autoFocus
                  />
                  <input
                    placeholder="Name (My Manager)"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="p-2 rounded bg-[#120b1a] text-white placeholder-purple-300"
                  />

                  {formError && <div className="text-red-400 text-sm">{formError}</div>}

                  <div className="flex justify-end gap-2 pt-2">
                    <button type="button" onClick={() => setShowModal(false)} className="px-3 py-1.5 rounded bg-gray-700">
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-3 py-1.5 rounded bg-green-600 text-white disabled:opacity-50"
                      disabled={!newDomain.trim() || !newName.trim()}
                    >
                      Add
                    </button>
                  </div>
                </form>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* toast */}
        <AnimatePresence>
          {toast && (
            <motion.div
              initial={{ y: 12, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 12, opacity: 0 }}
              className={`fixed right-6 bottom-6 z-50 rounded-lg px-4 py-2 shadow-xl ${
                toast.type === "ok" ? "bg-green-600/90 text-white" : "bg-red-600/90 text-white"
              }`}
            >
              {toast.text}
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

/* ---------------------- Manager Card (presentational + actions) ---------------------- */
function ManagerCard({
  im,
  index,
  onDelete,
  onAction,
}: {
  im: InstanceManager;
  index: number;
  onDelete: () => void;
  onAction: (a: "start" | "stop" | "restart") => void;
}) {
  const cpu = Math.min(100, Math.round(im.cpu_percent));
  const ram = Math.min(100, Math.round((im.ram_used_mb / Math.max(1, im.ram_total_mb)) * 100));
  const animatedCPU = useAnimatedNumber(cpu);
  const animatedRAM = useAnimatedNumber(ram);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: index * 0.06 }}
      className="relative p-8 bg-gradient-to-br from-black/50 to-purple-950/50 rounded-2xl shadow-xl border border-purple-950/40 flex flex-col md:flex-row gap-6"
    >
      {/* Delete button (now positioned absolute top-right for consistent layout) */}
      <div className="absolute right-3 bottom-3 z-10">
        <button
          onClick={onDelete}
          aria-label={`Delete ${im.name}`}
          title={`Delete ${im.name}`}
          className="w-9 h-9 rounded-full bg-white/5 hover:bg-red-600 flex items-center justify-center transition"
        >
          <Trash2 size={16} />
        </button>
      </div>

      {/* left meta - slightly wider so text has more room */}
      <div className="md:w-64 flex-shrink-0 text-white">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h4 className="text-lg font-semibold truncate">{im.name}</h4>
            <p className="text-xs text-purple-200/70 truncate">{im.domain}</p>
          </div>

          <span
            className={`ml-2 px-2 py-0.5 text-xs font-semibold rounded-full ${
              im.state === "Online"
                ? "bg-green-600 text-white"
                : im.state === "Warning"
                ? "bg-yellow-400 text-black"
                : "bg-red-600 text-white"
            }`}
          >
            {im.state}
          </span>
        </div>

        <div className="mt-4">
          <div className="flex justify-between text-xs text-purple-200/70 mb-1">
            <span>CPU</span>
            <span>{animatedCPU}%</span>
          </div>
          <div className="w-full h-2 rounded overflow-hidden bg-black/40 border border-purple-800/20">
            <motion.div
              className="h-2 rounded"
              animate={{ width: `${cpu}%` }}
              transition={{ type: "spring", stiffness: 120, damping: 22 }}
              style={{ background: "linear-gradient(90deg,#16a34a,#22c55e)" }}
            />
          </div>
        </div>

        <div className="mt-4">
          <div className="flex justify-between text-xs text-purple-200/70 mb-1">
            <span>RAM</span>
            <span>{animatedRAM}%</span>
          </div>
          <div className="w-full h-2 rounded overflow-hidden bg-black/40 border border-purple-800/20">
            <motion.div
              className="h-2 rounded"
              animate={{ width: `${ram}%` }}
              transition={{ type: "spring", stiffness: 120, damping: 22 }}
              style={{ background: "linear-gradient(90deg,#3b82f6,#60a5fa)" }}
            />
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          <button
            onClick={() => onAction("start")}
            className="px-3 py-1.5 rounded-md bg-green-600/90 text-white text-sm flex items-center gap-2 hover:brightness-105 transition"
          >
            <Play size={14} /> Start
          </button>
          <button
            onClick={() => onAction("stop")}
            className="px-3 py-1.5 rounded-md bg-red-600/90 text-white text-sm flex items-center gap-2 hover:brightness-95 transition"
          >
            <Pause size={14} /> Stop
          </button>
          <button
            onClick={() => onAction("restart")}
            className="px-3 py-1.5 rounded-md bg-blue-600/90 text-white text-sm flex items-center gap-2 hover:brightness-105 transition"
          >
            <RefreshCw size={14} /> Restart
          </button>
        </div>
      </div>

      {/* right: instances list — items are bigger and stretch nicely */}
      <div className="flex-1 space-y-3">
        {(!im.instances || im.instances.length === 0) && (
          <div className="text-xs text-purple-200/60 italic p-4 bg-black/20 rounded">No instances yet</div>
        )}

        {im.instances?.map((inst) => (
          <div
            key={inst.name}
            className="bg-[#12061b] rounded-xl shadow-inner text-white flex items-center justify-between p-4 min-h-[64px] border border-purple-800/30"
          >
            <div className="flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full ${inst.tps > 0 ? "bg-green-400" : "bg-red-500"} animate-pulse`} />
              <div>
                <p className="text-base font-semibold truncate">{inst.name}</p>
                <p className="text-xs text-purple-200/60">TPS: {inst.tps}</p>
              </div>
            </div>

            <div className="text-xs text-purple-200/60">{inst.players?.length ?? 0} players</div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
